/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */

// Obtener los elementos
const modal = document.getElementById('modal');
const openModal = document.getElementById('openModal');
const closeModal = document.getElementById('closeModal');

// Mostrar la ventana emergente
openModal.addEventListener('click', function(event) {
    event.preventDefault(); // Evitar la acción por defecto
    modal.style.display = 'flex'; // Mostrar el modal
});

// Cerrar la ventana emergente
closeModal.addEventListener('click', function() {
    modal.style.display = 'none'; // Ocultar el modal
});

// Cerrar el modal si se hace clic fuera de él
window.addEventListener('click', function(event) {
    if (event.target === modal) {
        modal.style.display = 'none';
    }
});

